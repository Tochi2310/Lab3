import java.util.ArrayList;
import java.util.Arrays;


	//Task 2
public class Task2 {

// function to print Array

public static void print2Darray(int[][] array){

for (int[] array1 : array) {

for (int j = 0; j < array1.length; j++) {

System.out.printf("%-3d", array1[j]);

}

System.out.println();

}}

public static int[][] runningSum2DArray(int[][] array, int dir)
{
  //Switch statements used for the directions
	//Used switch statements because they provide an easy way to execute different parts of code 
	//based on the value of the expression.
int[][] newArr=new int[array.length][array[0].length];
switch(dir)
{
case 1:
int i=0;
for (int[] array1 : array) {
int sum=0;
for (int j = array1.length-1; j >=0; j--) {
sum+=array1[j];
newArr[i][j]=sum;

}
i++;
}
break;
case 2:
i=0;
for (int[] array1 : array) {
int sum=0;
for (int j = 0; j <array1.length; j++) {
sum+=array1[j];
newArr[i][j]=sum;
}
i++;
}
break;
case 3:
for ( i = array.length-1 ; i >=0 ; i--) {
int sum=0;
for (int j =array[i].length-1 ; j >=0; j--) {
sum += array[j][i];
newArr[j][i]=sum;
}
}
break;
case 4:

for ( i = 0 ; i < array.length ; i++) {
int sum=0;
for (int j = 0 ; j < array[i].length; j++) {
sum += array[j][i];
newArr[j][i]=sum;
}
}
break;
}//Switch
return newArr;
}
// function to print ArrayList

public static void print2DList(ArrayList<ArrayList<Integer>> list){

list.forEach((b) -> {

b.forEach((i) -> {

System.out.printf("%-3d", i);

});

System.out.println();

});}

// Main method

public static void main(String args[]) {

// printing array

int[][] array = {{10, 15, 30, 40},{15, 5, 8, 2}, {20, 2, 4, 2},{1, 4, 5, 0}};

print2Darray(runningSum2DArray(array, 3));

// creates an arraylist and inserts elements and prints them 

ArrayList<ArrayList<Integer>> list = new ArrayList<>();

for (int[] array1 : array) {

ArrayList<Integer> a = new ArrayList<>();

for (int j = 0; j < array1.length; j++) { a.add(array1[j]); }

list.add(a); }

print2DList(list);}}