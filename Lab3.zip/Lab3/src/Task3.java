
	import java.util.ArrayList;
	import java.util.Arrays;
	import java.util.Iterator;

	public class Task3 {

	    // Using basic while / for loop
	    void printArrayListBasicLoop(ArrayList<Integer> al) {
	        for (int i = 0; i < al.size(); i++) {
	            System.out.println(al.get(i));
	        }
	    }

	    // Using enhanced for loop (:)
	    void printArrayListEnhancedLoop(ArrayList<Integer> al) {
	        for (Integer num : al) {
	            System.out.println(num);
	        }
	    }

	    // Using basic for loop with iterator
	    void printArrayListForLoopListIterator(ArrayList<Integer> al) {
	        for (Iterator<Integer> it = al.iterator(); it.hasNext(); ) {
	            System.out.println(it.next());
	        }
	    }

	    // Using basic while loop with iterator
	    void printArrayListWhileLoopListIterator(ArrayList<Integer> al) {
	        Iterator<Integer> it = al.iterator();
	        while (it.hasNext()) {
	            System.out.println(it.next());
	        }
	    }
	    //Main method
	    public static void main(String[] args) {
	        ArrayList<Integer> list = new ArrayList<>(Arrays.asList(3, 8, 1, 9));
	        new Task3().printArrayListBasicLoop(list);
	        System.out.println();
	        new Task3().printArrayListEnhancedLoop(list);
	        System.out.println();
	        new Task3().printArrayListForLoopListIterator(list);
	        System.out.println();
	        new Task3().printArrayListWhileLoopListIterator(list);
	        System.out.println();
	    }
	}

