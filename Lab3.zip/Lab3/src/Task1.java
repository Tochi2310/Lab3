import java.util.ArrayList;
public class Task1 {
	
// function to print Array
public static void print2Darray(int[][] array){
   for (int[] arrayI : array) {
   for (int j = 0; j < arrayI.length; j++) {
       System.out.printf("%-3d", arrayI[j]);
   }
   System.out.println();
   }
}
// function to print ArrayList
public static void print2DList(ArrayList<ArrayList<Integer>> list){
   list.forEach((a) -> {
   a.forEach((i) -> {
       System.out.printf("%-3d", i);
   });
   System.out.println();
   });
}
// main method
public static void main(String args[]) {
   // printing array
int[][] array = {{10, 15, 30, 40},{15, 5, 8, 2}, {20, 2, 4, 2},{1, 4, 5, 0}};
print2Darray(array);
   // creates an arraylist and inserts elements and then prints them
   ArrayList<ArrayList<Integer>> list = new ArrayList<>();
   for (int[] array1 : array) {
   ArrayList<Integer> a = new ArrayList<>();
   for (int j = 0; j < array1.length; j++) { a.add(array1[j]); }
   list.add(a);
   }
   print2DList(list);
}
}